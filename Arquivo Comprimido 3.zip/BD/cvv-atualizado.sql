CREATE DATABASE cvv;
USE cvv;

CREATE TABLE usuario (
	idUsuario INT PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(45),
	email VARCHAR(45),
	senha VARCHAR(45)
);

CREATE TABLE acesso (
idAcesso int primary key auto_increment,
cliques datetime
) auto_increment = 100; 

create table telefone(
idTelefone int primary key auto_increment,
celular varchar(45),
fkUsuario int,
foreign key (fkUsuario) references usuario (idUsuario)
) auto_increment =1000;


select * from usuario;
insert into usuario values
(null, '${nome}', '${email}', '${senha}');